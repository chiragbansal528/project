$(document).ready(function () {
    // Animate welcome screen text
    setTimeout(function () {
        $("#banner h1").fadeOut(1500);
        $("#banner h1").slideDown(1500);
    }, 1500);
    });